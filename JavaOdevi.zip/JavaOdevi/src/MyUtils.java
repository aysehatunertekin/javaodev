import java.util.Scanner;

public class MyUtils {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	    int test_rakami=9;
		Scanner sc = new Scanner(System.in); 
		while(test_rakami!=0){//
			//Control paneli
			System.out.println("\n");
			System.out.println("1'e Basinca cokgenin çevresini bulunur");
			System.out.println("2'e Basinca cokgenin alanını bulunur");
			System.out.println("3'e Basinca uçgenin çevresini bulunur");
			System.out.println("4'e Basinca uçgenin alanını bulunur");
			System.out.println("5'e Basinca -100 ile 100 arasindaki tamsayilar icin");
			System.out.println("0'e Basinca systemden cikiyorsunuz");
			test_rakami = sc.nextInt();
			
			if(test_rakami==1 || test_rakami==2){
				float KISAk,UZUNK,cokgenCever; 
				System.out.println("kisa kenari giriniz");
				KISAk = sc.nextFloat();
				System.out.println("Uzun kenari giriniz");
				UZUNK = sc.nextFloat();
				if(test_rakami==1)
			        System.out.println("cokgenin çevresini sonuc = "+cokgenCevre(KISAk,UZUNK));
				else 
					System.out.println("cokgenin alanını sonuc = "+ cokgenAlan(KISAk,UZUNK));	
			}
			
			if(test_rakami==3||test_rakami==4){
				float kenar1,kenar2,kenar3; 
				if(test_rakami==3){
					System.out.println("Birinci Üçgenin kenari gir");
					kenar1 = sc.nextFloat();
					System.out.println("Ikinci Üçgenin kenari gir");
					kenar2 = sc.nextFloat();
					System.out.println("ucuncu Üçgenin kenari gir");
					kenar3 = sc.nextFloat();
					System.out.println("üçgenin çevresini sonuc ="+ucgenCevre(kenar1,kenar2,kenar3));
				}
				else{
					float TABAN; 
					float uzunluk; 
					System.out.println("Taban giriniz");
					TABAN = sc.nextFloat();
					System.out.println("Yükseklik  giriniz");
					uzunluk = sc.nextFloat();
					System.out.println("üçgenin alanını sonuc ="+ucgenAlan(TABAN,uzunluk));
					
				}
					
			}
			if(test_rakami==5){
				TamSayilar();
			}
			if(test_rakami==0){
				System.exit(0);
			}
		}
		
	}
	public static float cokgenCevre(float KISAk , float UZUNK){
		float sonuc;
		sonuc=(KISAk*UZUNK)*2;
		return sonuc;
		}
	public static float cokgenAlan(float KISAk, float UZUNK){
		float sonuc; 
		sonuc = KISAk*UZUNK;
		return sonuc;
		}
	public static float ucgenCevre(float kenar1, float kenar2, float kenar3){
		float sonuc=0; 
		sonuc = kenar1 + kenar2 + kenar3; 
		return sonuc;
	}
	public static float ucgenAlan(float Taban , float Yukeklik){
		float sonuc; 
		sonuc =(Taban * Yukeklik)/2;
		return sonuc;
		}
	public static void TamSayilar(){
		 int sayac=0;
		 long tamSayi=-100;
		 long array[] = new long[200];	
		while(tamSayi<99){
			++tamSayi;
			array[sayac]=tamSayi;
		    
			System.out.print(array[sayac]+"\t");
			if(sayac%4==0){
		     	System.out.println();
			}
			sayac++;	
		}
 
	}
}
